import { Routes, Route, Navigate } from "react-router-dom";

// Layout
import MainLayout from "@/apps/admin/layouts/MainLayout";



// Pages

import Educatiionpipeline from "@/apps/admin/pages/Educatiionpipeline/Educatiionpipeline";
import EnquirySheet from "@/apps/admin/pages/EnquirySheet/EnquirySheet";
import LeadSummaryReport from "@/apps/admin/pages/LeadSummaryReport/LeadSummaryReport";


function AdminRoutes() {
  return (
    <Routes>
      {/* Main Admin Layout */}
      <Route element={<MainLayout />}>
        <Route path="Educatiionpipeline" element={<Educatiionpipeline />} />
        <Route path="enquiry-sheet/:campaignId" element={<EnquirySheet />} />
        <Route path="lead-summary-report" element={<LeadSummaryReport />} />
      </Route>

      {/* Default redirect */}
      <Route path="*" element={<Navigate to="/admin/Educatiionpipeline" replace />} />
    </Routes>
  );
}

export default AdminRoutes;
