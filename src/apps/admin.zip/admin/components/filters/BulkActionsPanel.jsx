import { Box, Typography, MenuList, MenuItem, ListItemIcon, ListItemText } from "@mui/material";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import SwapHorizOutlinedIcon from "@mui/icons-material/SwapHorizOutlined";
import ContentCopyOutlinedIcon from "@mui/icons-material/ContentCopyOutlined";
import CloseIcon from "@mui/icons-material/Close";

const actions = [
  { label: "Update", icon: DescriptionOutlinedIcon },
  { label: "Delete", icon: DeleteOutlineOutlinedIcon },
  { label: "Move to Other Campaign", icon: SwapHorizOutlinedIcon },
  { label: "Copy to Other Campaign", icon: ContentCopyOutlinedIcon },
  { label: "Close Leads", icon: CloseIcon },
];

function BulkActionsPanel({ onSelect, disabled = false }) {
  return (
    <Box sx={{ p: 2, minWidth: 280 }}>
      <Typography
        sx={{
          fontFamily: "'Inter', sans-serif",
          color: "#2E7D32",
          fontWeight: 700,
          fontSize: 14,
          mb: 1,
        }}
      >
        Choose Bulk Actions
      </Typography>

      <MenuList sx={{ p: 0 }}>
        {actions.map(({ label, icon: Icon }) => (
          <MenuItem
            key={label}
            onClick={() => onSelect?.(label)}
            sx={{
              px: 1,
              py: 0.8,
              borderRadius: "6px",
              color: "#333333",
              opacity: 1,
              "&:hover": {
                bgcolor: "#F5F5F5",
              },
            }}
          >
            <ListItemIcon sx={{ minWidth: 32, color: "#555555" }}>
              <Icon fontSize="small" />
            </ListItemIcon>
            <ListItemText
              primary={label}
              primaryTypographyProps={{
                fontFamily: "'Inter', sans-serif",
                fontWeight: 500,
                fontSize: 14,
                color: "#333333",
                whiteSpace: "nowrap", // 👈 🌟 NO TEXT TRUNCATION (மறைவு எதும் இருக்காது)
              }}
            />
          </MenuItem>
        ))}
      </MenuList>
    </Box>
  );
}

export default BulkActionsPanel;