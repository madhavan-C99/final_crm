import api from "@/shared/services/axios";

export const getCampaignStatsTile = async (payload) => {
    return api.get(
        "/adm/campaign_stats_tile",
        payload
    );
};