import api from "@/shared/services/axios";

// 🌟 1. Fetch Dropdown Filter Options
export const getFilterOptions = async () => {
  return api.get("adm/filter_options");
};

// 🌟 2. Fetch Lead Summary Report Table Data with Filters
export const getLeadSummaryReport = async (params = {}) => {
  return api.get("adm/lead_summary_report", { params });
};