import api from "@/shared/services/axios";

export const getCampaignEnquirySheet = async (campaignId, campaignName) => {
    return api.get("/adm/campaign_enquiry_sheet", {
        params: {
            ...(campaignId && { campaign_id: campaignId }),
            ...(campaignName && { campaign_name: campaignName }),
        }
    });
};