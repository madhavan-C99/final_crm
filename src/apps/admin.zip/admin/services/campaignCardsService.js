import api from "@/shared/services/axios";

export const getCampaignCards = async () => {
    return api.get("/adm/campaign_cards_tile");
};