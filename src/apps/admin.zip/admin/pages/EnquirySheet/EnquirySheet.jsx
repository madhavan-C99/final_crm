import { useEffect, useState } from "react";
import { useParams, useSearchParams, useNavigate } from "react-router-dom";
import { Box, Skeleton } from "@mui/material";
import SheetHeader from "@/apps/admin/pages/EnquirySheet/components/SheetHeader";
import SheetCard from "@/apps/admin/pages/EnquirySheet/components/SheetCard";
import LeadDistributionTable from "@/apps/admin/pages/EnquirySheet/components/LeadDistributionTable";
import { getCampaignEnquirySheet } from "@/apps/admin/services/enquirySheetService";

const GRADIENT_MAP = {
  "Total Leads": "linear-gradient(230.65deg, #EEF1F4 -42.71%, #E1F0FF 90.89%)",
  "New Lead": "linear-gradient(230.65deg, #EEF1F4 -42.71%, #C8E3FF 90.89%)",
  "1st Time Not picked": "linear-gradient(230.65deg, #FFEBD0 -42.71%, #FFD6A0 90.89%)",
  "Follow Up": "linear-gradient(230.65deg, #EEF1F4 -42.71%, #FCAFEF 90.89%)",
  "Missed Follow Up": "linear-gradient(230.65deg, #EEF1F4 -42.71%, #FFFB89 90.89%)",
  "Not Connected": "linear-gradient(230.65deg, #EEF1F4 -42.71%, #FFBFA7 90.89%)",
  "Won": "linear-gradient(230.65deg, #EEF1F4 -42.71%, #C3FF5E 90.89%)",
  "Lost": "linear-gradient(230.65deg, #EEF1F4 -42.71%, #FF8D8D 90.89%)",
};

const defaultStats = [
  { label: "Total Leads", value: 0, bg: GRADIENT_MAP["Total Leads"], color: "#194066" },
  { label: "New Lead", value: 0, bg: GRADIENT_MAP["New Lead"], color: "#194066" },
  { label: "1st Time Not picked", value: 0, bg: GRADIENT_MAP["1st Time Not picked"], color: "#194066" },
  { label: "Follow Up", value: 0, bg: GRADIENT_MAP["Follow Up"], color: "#194066" },
  { label: "Missed Follow Up", value: 0, bg: GRADIENT_MAP["Missed Follow Up"], color: "#194066" },
  { label: "Not Connected", value: 0, bg: GRADIENT_MAP["Not Connected"], color: "#194066" },
  { label: "Won", value: 0, bg: GRADIENT_MAP["Won"], color: "#194066" },
  { label: "Lost", value: 0, bg: GRADIENT_MAP["Lost"], color: "#194066" },
];

function EnquirySheet() {
  const { campaignId } = useParams();
  const [searchParams] = useSearchParams();
  const campaignNameParam = searchParams.get("campaign_name");
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [title, setTitle] = useState("Enquiry Sheet");
  const [stats, setStats] = useState(defaultStats);
  const [rows, setRows] = useState([]);
  const [rawCampaignName, setRawCampaignName] = useState("");

  const loadEnquiryData = async () => {
    try {
      setLoading(true);
      const res = await getCampaignEnquirySheet(campaignId, campaignNameParam);
      const resData = res?.data?.data;

      if (resData) {
        if (resData.campaign_name) {
          setTitle(`${resData.campaign_name} Enquiry Sheet`);
          setRawCampaignName(resData.campaign_name);
        }
        if (resData.stats) {
          const updatedStats = resData.stats.map((s) => ({
            ...s,
            bg: GRADIENT_MAP[s.label] || s.bg,
            color: "#194066",
          }));
          setStats(updatedStats);
        }
        if (resData.distribution_rows) setRows(resData.distribution_rows);
      }
    } catch (err) {
      console.error("Failed to load enquiry sheet data:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEnquiryData();
  }, [campaignId, campaignNameParam]);

  const handleBack = () => navigate(-1);

  // 🌟 CAMPAIGN DETAILS-ஐ PASS செய்து LEAD SUMMARY REPORT-க்கு சொ செல்லுதல்
  const handleLeadSummary = () => {
    const query = new URLSearchParams();
    if (campaignId) query.set("campaign_id", campaignId);
    const activeCampName = rawCampaignName || campaignNameParam;
    if (activeCampName) query.set("campaign_name", activeCampName);
    
    navigate(`/admin/lead-summary-report?${query.toString()}`);
  };

  return (
    <Box sx={{ p: { xs: 1, sm: 2 } }}>
      <SheetHeader
        title={title}
        onBack={handleBack}
        onLeadSummary={handleLeadSummary}
      />

      {loading ? (
        <>
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: {
                xs: "repeat(4, 1fr)",
                sm: "repeat(4, 1fr)",
                md: "repeat(8, 1fr)",
              },
              gap: 1.5,
              mb: 2.5,
            }}
          >
            {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
              <Skeleton key={n} variant="rectangular" width="100%" height={75} sx={{ borderRadius: 2 }} />
            ))}
          </Box>
          <Skeleton variant="rectangular" width="100%" height={280} sx={{ borderRadius: 2 }} />
        </>
      ) : (
        <>
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: {
                xs: "repeat(4, 1fr)",
                sm: "repeat(4, 1fr)",
                md: "repeat(8, 1fr)",
              },
              gap: 1.5,
              mb: 2.5,
            }}
          >
            {stats.map((s) => (
              <SheetCard key={s.label} {...s} />
            ))}
          </Box>

          <LeadDistributionTable rows={rows} onRefresh={loadEnquiryData} />
        </>
      )}
    </Box>
  );
}

export default EnquirySheet;