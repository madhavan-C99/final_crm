import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Box } from "@mui/material";

// 🌟 IMPORTING FROM ADMIN SERVICES (FOLLOWING YOUR PROJECT STRUCTURE)
import { getFilterOptions, getLeadSummaryReport } from "@/apps/admin/services/leadSummaryService";

import LeadSummaryHeader from "@/apps/admin/pages/LeadSummaryReport/components/LeadSummaryHeader";
import LeadSummaryToolbar from "@/apps/admin/pages/LeadSummaryReport/components/LeadSummaryToolbar";
import LeadSummaryTable from "@/apps/admin/pages/LeadSummaryReport/components/LeadSummaryTable";

function LeadSummaryReport() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  const campaignId = searchParams.get("campaign_id");
  const initialCampaignName = searchParams.get("campaign_name") || "500 Enquiry Sheet";

  const [campaignName, setCampaignName] = useState(initialCampaignName);
  const [search, setSearch] = useState("");
  const [selectedIds, setSelectedIds] = useState([]);
  const [tableRows, setTableRows] = useState([]);
  const [loading, setLoading] = useState(true);

  // DYNAMIC FILTER STATES
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [selectedStages, setSelectedStages] = useState([]);
  const [panelFilters, setPanelFilters] = useState({});

  const [filterOptionsData, setFilterOptionsData] = useState({
    campaigns: ["All"],
    courses: ["All"],
    coursePlans: ["All"],
    sources: ["All"],
    paymentStatuses: ["All"],
    priorities: ["All"],
    telecallers: ["Gokil Gokil", "Bharath"],
  });

  // 1. 🌟 CALLING SERVICE METHOD FOR FILTER OPTIONS
  useEffect(() => {
    async function loadSelectOptions() {
      try {
        const response = await getFilterOptions();
        if (response.data && response.data.data) {
          const apiData = response.data.data;
          
          setFilterOptionsData({
            campaigns: apiData.campaigns || ["All"],
            courses: apiData.courses || ["All"],
            coursePlans: apiData.course_plans || ["All"],
            sources: apiData.lead_sources || ["All"],
            paymentStatuses: apiData.payment_statuses || ["All"],
            priorities: apiData.priorities || ["All"],
            telecallers: apiData.telecallers || ["Gokil Gokil", "Bharath"],
          });
        }
      } catch (error) {
        console.error("Filter options load error:", error);
      }
    }
    loadSelectOptions();
  }, []);

  // 2. 🌟 CALLING SERVICE METHOD FOR SUMMARY REPORT DATA
  useEffect(() => {
    async function loadLeadSummaryData() {
      setLoading(true);
      try {
        const queryParams = {
          campaign_id: campaignId,
          campaign_name: initialCampaignName,
          search: search,
          date_range: selectedDate,
          assigned_to: selectedUsers.join(","),
          stages: selectedStages.join(","),
          filter_campaign: panelFilters.campaignName,
          course_name: panelFilters.courseName,
          course_plan: panelFilters.coursePlan,
          lead_source: panelFilters.leadSource,
          payment_status: panelFilters.paymentStatus,
          priority: panelFilters.priority,
        };

        const response = await getLeadSummaryReport(queryParams);

        if (response.data && response.data.data) {
          setCampaignName(response.data.data.campaign_name || initialCampaignName);
          setTableRows(response.data.data.rows || []);
        }
      } catch (error) {
        console.error("Failed to load lead summary data:", error);
      } finally {
        setLoading(false);
      }
    }

    loadLeadSummaryData();
  }, [
    campaignId,
    initialCampaignName,
    search,
    selectedDate,
    selectedUsers,
    selectedStages,
    panelFilters,
  ]);

  return (
    <Box sx={{ width: "100%", maxWidth: "100%", p: 2 }}>
      <LeadSummaryHeader
        title={`Lead Summary Report- ${campaignName}`}
        onBack={() => navigate(-1)}
        onCallLogs={() => console.log("Call logs clicked")}
      />

      <LeadSummaryToolbar
        search={search}
        onSearchChange={setSearch}
        selectedCount={selectedIds.length}
        filterDropdownOptions={filterOptionsData}
        telecallers={filterOptionsData.telecallers}
        selectedDate={selectedDate}
        selectedUsers={selectedUsers}
        selectedStages={selectedStages}
        appliedPanelFilters={panelFilters}
        onDateApply={(val) => setSelectedDate(val)}
        onUserApply={(vals) => setSelectedUsers(vals)}
        onStageApply={(vals) => setSelectedStages(vals)}
        onFilterApply={(filterData) => setPanelFilters(filterData)}
        onBulkAction={(action) => console.log("Bulk action:", action, selectedIds)}
      />

      <LeadSummaryTable
        rows={tableRows}
        loading={loading}
        onEdit={(row) => console.log("Edit", row)}
        onView={(row) => console.log("View", row)}
        onDelete={(row) => console.log("Delete", row)}
        onSelectionChange={setSelectedIds}
      />
    </Box>
  );
}

export default LeadSummaryReport;